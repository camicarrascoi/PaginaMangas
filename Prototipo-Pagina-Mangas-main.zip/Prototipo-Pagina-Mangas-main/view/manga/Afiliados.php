<h3 class="titulo-seccion">Tiendas Afiliadas</h3>

<div class="divAfiliados">
    <p>
        Por el momento no hay tiendas Afiliadas
    </p>

</div>
