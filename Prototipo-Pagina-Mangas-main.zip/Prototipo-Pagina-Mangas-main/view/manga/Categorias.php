
<section class="contenedor-generos">
 
    <div class="Busqueda">
      <input type="search" id="buscarTitulo" placeholder="Busca tu manga favorito" onchange="redirigirBusqueda()">
    </div>
    </div>
    <h2>Explora por Géneros</h2>
    <div class="grid-generos" id="lista-generos">
      <!-- Los géneros se insertarán aquí con JavaScript -->
    </div>

</section>