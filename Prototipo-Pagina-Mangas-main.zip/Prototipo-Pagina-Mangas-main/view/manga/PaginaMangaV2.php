<div class="Busqueda">
    <input type="search" id="buscarTitulo" placeholder="Busca tu manga favorito" onchange="redirigirBusqueda()">
</div>
<!--Contenedor recomendaciones-->
<div class="Recomm">
    <p>Nuestras Recomendaciones UwU</p><!--Parrafo-->
</div>
<!--ContenedorImagenes-->
<div class="contenedorImagenes">
    <!--Contenedor MangaFoto-->
    <div class="mangafoto">
        <a href="index.php?controller=kiwi&action=detalles&id=4632">
            <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjHfz13bXceGVN-pF5clN1F8VOyliDaY0oszbjyKT0utdU47awlgrdwtw0rC2C2wK1Q_mlvax6BMZ7YxXZs7psAHTtiSwu3j1vUGsu5wCx0va3MXB1vLCo4SdN33Fw-hM40qYXAi10lsgY/s1600/punpun.png"
                alt=""><!--Imagen-->
            <p class="Titulo">Oyasumin Punpun</p><!--Parrafo-->
        </a>
    </div><!--Fin del Contenedor MangaFoto-->
    <!--Contenedor MangaFoto-->
    <div class="mangafoto">
        <a href="index.php?controller=kiwi&action=detalles&id=2">
            <img src="https://cdn.myanimelist.net/images/about_me/main_visual/18524224-de15dfc4-330e-4944-afd3-959eecfcec03.png?t=1734909623"
                alt=""><!--Imagen-->
            <p class="Titulo">Berserk</p><!--Parrafo-->
        </a>
    </div><!--Fin del Contenedor MangaFoto-->
    <!--Contenedor MangaFoto-->
    <div class="mangafoto">
        <a href="index.php?controller=kiwi&action=detalles&id=28">
            <img src="https://areajugones.sport.es/wp-content/uploads/2025/01/nana-hiatus-manga-1.jpg"
                alt=""><!--Imagen-->
            <p class="Titulo">Nana</p><!--Parrafo-->
        </a>
    </div><!--Fin del Contenedor MangaFoto-->
    <!--Contenedor MangaFoto-->
    <div class="mangafoto">
        <a href="index.php?controller=kiwi&action=detalles&id=116778">
            <img src="https://i0.wp.com/elpalomitron.com/wp-content/uploads/2020/10/Resena-de-Chainsaw-Man-destacada-El-Palomitron.jpg?resize=1000%2C600&ssl=1"
                alt=""><!--Imagen-->
            <p class="Titulo">MotoSierra</p><!--Parrafo-->
        </a>
    </div><!--Fin del Contenedor MangaFoto-->
    <!--Contenedor MangaFoto-->
    <div class="mangafoto">
        <a href="index.php?controller=kiwi&action=detalles&id=26">
            <img src="https://lavacajaponesa.com/wp-content/uploads/2024/10/91f6iVYeN0L._SL1500_.jpg"
                alt=""><!--Imagen-->
            <p class="Titulo">HunterxHunter</p><!--Parrafo-->
        </a>
    </div><!--Fin del Contenedor MangaFoto-->
    <!--Contenedor MangaFoto-->
    <div class="mangafoto">
        <a href="index.php?controller=kiwi&action=detalles&id=126287">
            <img src="https://www.anmosugoi.com/wp-content/uploads/2022/08/Sousou-no-Frieren-manga-vol-9-min.jpg"
                alt=""><!--Imagen-->
            <p class="Titulo">Frieren</p><!--Parrafo-->
        </a>
    </div><!--Fin del Contenedor MangaFoto-->
</div><!--Fin del ContenedorImagenes-->
<section class="Populares">
    <div class="Container">
        <p>Populares🔥</p>
    </div>
    <div class="ListaPopulares mangas"></div>
</section>
<section class="Populares">
    <div class="Container">
        <p>Los personajes mas aclamados❤️</p>
    </div>
    <div class="ListaPopulares personajes"></div>
</section>