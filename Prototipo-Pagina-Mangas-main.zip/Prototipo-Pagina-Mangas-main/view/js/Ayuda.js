function toggleRespuesta(elemento) {
  const respuesta = elemento.querySelector('.respuesta');
  respuesta.style.display = respuesta.style.display === 'block' ? 'none' : 'block';
}